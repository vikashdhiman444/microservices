package com.fis.book.exception;

public class NoDataFoundException extends Exception {

}
