package com.fis.subscription.exception;

public class NoDataFoundException extends Exception {

}
